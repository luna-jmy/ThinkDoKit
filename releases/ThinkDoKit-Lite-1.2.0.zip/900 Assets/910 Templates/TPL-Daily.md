---
journal: Daily
journal-date: 
type: daily_log
created: <% tp.date.now() %>
tags:
  - journal/daily
cssclasses:
  - matrix
---

```journals-home
show:
  - day
  - week
  - month
  - year
scale: 1
separator: " | "
```

```calendar-nav

```

# <% tp.file.title %> 日志
***日事日毕，日清日高***  `button-sjournalMetadata`

## ✨ 今日关注
>*此处记录当日最重要的任务、日程和灵感。如在手机端使用，推荐用按钮添加待办*

- ***今天应改进的事***： `$={const p=dv.pages('"500 Journal/540 Daily"').find(p=>p.file.name===new Date(new Date(dv.current().file.name).setDate(new Date(dv.current().file.name).getDate()-1)).toISOString().split('T')[0]);p?p["明天想改进的事"]:"未找到前一天的日志或字段"}`

### 🔍今日到期任务
```tasks
not done
due by today
has due date
path does not include 500 Journal/540 Daily
```

---

## 👀 GTD任务看板
`button-stodoToday`
> *提示: 通过 `Tasks插件` 的快捷键 `Alt+t` 可以快速帮你在这里添加/编辑任务。也可以通过在任意笔记的任意位置使用 `QuickAdd: 📌 AddTodoToday` 随时添加今日待办*


> *提示: 点击下方按钮👇可将前一日未完成的任务转移到此处。*
`button-staskRollover`


## 🗓️ 日程安排
> *提示: Day Planner 插件可以在侧边栏或主区域显示当日时间线。调整时间段即可更改日程时间块显示。*
`button-sdayPlanner`


## 📈 习惯记录

### 每日打卡
`button-tracker`
- [💊medicine::]
- [🧠flashcard::]
- [🧘‍♂️meditation::]
- [🍽️fasting::]
%%（布尔值🔲✔️❌）%% 
### 数据记录
`button-data`
- [weight⚖️::]
- [exercise🕓::]
- [reading🕓::]
- [saving💰::]
- [spent💰::]
%%仅可填写数值；图标单位含义：⚖️公斤kg；🕓分钟；⏳小时；📅日；💰元；💸万元；🧮次数%%
## ✍️ 今日小结与回顾
`^button-supdate`
- [今天最满意的事::]
- [今天遇到的障碍或困难::]
- [今天印象最深刻的事::]
- [明天想改进的事::] 

## 💡 灵感与思考


## 📥 收件箱清理
- 待完成任务（不含当日）：
```tasks
path includes 540 Daily
tags include #inbox
not done
filename does not include {{date:YYYY-MM-DD}}
```

- 待整理日志：
```dataview
TABLE file.ctime AS "创建日期", file.mtime AS "最后修改时间"
WHERE startswith(file.path, "000 Inbox") OR contains(tags, "inbox")
WHERE file.name != "Inbox Note List"
WHERE !startswith(file.path, "500 Journal")
SORT file.mtime DESC
```


